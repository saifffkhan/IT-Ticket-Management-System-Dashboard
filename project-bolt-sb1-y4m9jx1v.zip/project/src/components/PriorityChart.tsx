import React from 'react';
import { Ticket } from '../types';

interface PriorityChartProps {
  tickets: Ticket[];
}

export function PriorityChart({ tickets }: PriorityChartProps) {
  const priorityCounts = {
    critical: tickets.filter(t => t.priority === 'critical').length,
    high: tickets.filter(t => t.priority === 'high').length,
    medium: tickets.filter(t => t.priority === 'medium').length,
    low: tickets.filter(t => t.priority === 'low').length,
  };

  const total = Object.values(priorityCounts).reduce((a, b) => a + b, 0);

  return (
    <div className="space-y-4">
      {Object.entries(priorityCounts).map(([priority, count]) => (
        <div key={priority} className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="font-medium capitalize">{priority}</span>
            <span className="text-gray-500">{Math.round((count / total) * 100)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className={`h-2 rounded-full ${
                priority === 'critical' ? 'bg-red-500' :
                priority === 'high' ? 'bg-orange-500' :
                priority === 'medium' ? 'bg-yellow-500' :
                'bg-gray-500'
              }`}
              style={{ width: `${(count / total) * 100}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}