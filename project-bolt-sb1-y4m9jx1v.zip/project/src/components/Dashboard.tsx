import React from 'react';
import { BarChart3, Clock, AlertCircle, CheckCircle2 } from 'lucide-react';
import { mockTickets } from '../data';
import { TicketList } from './TicketList';
import { StatsCard } from './StatsCard';
import { PriorityChart } from './PriorityChart';

export function Dashboard() {
  const stats = {
    total: mockTickets.length,
    open: mockTickets.filter(t => t.status === 'open').length,
    inProgress: mockTickets.filter(t => t.status === 'in_progress').length,
    resolved: mockTickets.filter(t => t.status === 'resolved').length,
    slaCompliance: 85, // Mock value
    avgResolutionTime: 18.5 // Mock value in hours
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">IT Support Dashboard</h1>
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
            New Ticket
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Total Tickets"
            value={stats.total}
            icon={<BarChart3 className="h-6 w-6 text-blue-600" />}
            trend="+12% from last week"
          />
          <StatsCard
            title="Open Tickets"
            value={stats.open}
            icon={<AlertCircle className="h-6 w-6 text-yellow-600" />}
            trend="-5% from last week"
          />
          <StatsCard
            title="SLA Compliance"
            value={`${stats.slaCompliance}%`}
            icon={<Clock className="h-6 w-6 text-green-600" />}
            trend="+3% from last week"
          />
          <StatsCard
            title="Resolved Today"
            value={stats.resolved}
            icon={<CheckCircle2 className="h-6 w-6 text-purple-600" />}
            trend="+2 from yesterday"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <div className="lg:col-span-2 bg-white rounded-lg shadow">
            <div className="p-6">
              <h2 className="text-xl font-semibold mb-4">Recent Tickets</h2>
              <TicketList tickets={mockTickets} />
            </div>
          </div>
          <div className="bg-white rounded-lg shadow">
            <div className="p-6">
              <h2 className="text-xl font-semibold mb-4">Ticket Priority Distribution</h2>
              <PriorityChart tickets={mockTickets} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}