import { Ticket } from './types';

export const mockTickets: Ticket[] = [
  {
    id: 'TIC-001',
    title: 'Unable to access email',
    description: 'Getting error message when trying to open Outlook',
    priority: 'high',
    category: 'software',
    status: 'open',
    assignedTo: 'John Smith',
    createdAt: '2024-03-10T08:00:00Z',
    updatedAt: '2024-03-10T08:00:00Z',
    sla: 4
  },
  {
    id: 'TIC-002',
    title: 'Printer not responding',
    description: 'Third floor printer showing offline status',
    priority: 'medium',
    category: 'hardware',
    status: 'in_progress',
    assignedTo: 'Sarah Johnson',
    createdAt: '2024-03-09T15:30:00Z',
    updatedAt: '2024-03-10T09:00:00Z',
    sla: 8
  },
  {
    id: 'TIC-003',
    title: 'New employee setup',
    description: 'Need complete workstation setup for new hire starting Monday',
    priority: 'medium',
    category: 'access',
    status: 'open',
    assignedTo: null,
    createdAt: '2024-03-10T10:15:00Z',
    updatedAt: '2024-03-10T10:15:00Z',
    sla: 24
  },
  {
    id: 'TIC-004',
    title: 'Network connectivity issues',
    description: 'Intermittent network drops in meeting room 2',
    priority: 'critical',
    category: 'network',
    status: 'in_progress',
    assignedTo: 'Mike Wilson',
    createdAt: '2024-03-10T09:45:00Z',
    updatedAt: '2024-03-10T10:30:00Z',
    sla: 2
  },
  {
    id: 'TIC-005',
    title: 'Software installation request',
    description: 'Need Adobe Creative Suite installed',
    priority: 'low',
    category: 'software',
    status: 'resolved',
    assignedTo: 'Sarah Johnson',
    createdAt: '2024-03-08T14:20:00Z',
    updatedAt: '2024-03-09T11:00:00Z',
    sla: 48,
    timeToResolution: 20.6
  }
];