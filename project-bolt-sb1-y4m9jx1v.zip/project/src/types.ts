export interface Ticket {
  id: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  category: 'hardware' | 'software' | 'network' | 'access' | 'other';
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  assignedTo: string | null;
  createdAt: string;
  updatedAt: string;
  sla: number; // in hours
  timeToResolution?: number; // in hours
}

export interface TicketStats {
  total: number;
  open: number;
  inProgress: number;
  resolved: number;
  slaCompliance: number;
  avgResolutionTime: number;
}